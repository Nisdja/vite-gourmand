<?php

class CalculPrixService
{
    /**
     * Calcule le prix d'une commande.
     *
     * Règles métier :
     * - Prix proportionnel au nombre de personnes
     * - Réduction de 10% si minimum + 5 personnes
     * - Livraison gratuite à Bordeaux
     * - Livraison : 5 € hors Bordeaux
     */
    public static function calculer(
        float $prixBase,
        int $minimumPersonnes,
        int $nombrePersonnes,
        string $ville
    ): array {

        if ($nombrePersonnes < $minimumPersonnes) {
            $nombrePersonnes = $minimumPersonnes;
        }

        // Prix par personne
        $prixParPersonne = $prixBase / $minimumPersonnes;

        // Prix du menu
        $prixMenu = $prixParPersonne * $nombrePersonnes;

        // Remise
        $remise = 0;

        if ($nombrePersonnes >= ($minimumPersonnes + 5)) {
            $remise = $prixMenu * 0.10;
        }

        // Livraison
        $prixLivraison = 0;

        if (mb_strtolower(trim($ville)) !== "bordeaux") {
            $prixLivraison = 5;
        }

        // Total
        $prixTotal = $prixMenu - $remise + $prixLivraison;

        return [

            "prix_menu" => round($prixMenu, 2),

            "prix_livraison" => round($prixLivraison, 2),

            "remise" => round($remise, 2),

            "prix_total" => round($prixTotal, 2)

        ];
    }
}