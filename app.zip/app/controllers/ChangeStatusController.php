<?php

require_once "../app/config/database.php";
require_once "../app/helpers/session.php";
require_once "../app/models/Commande.php";

if (!isset($_SESSION["user"])) {
    header("Location: ../public/login.php");
    exit();
}

if (
    $_SESSION["user"]["role"] !== "employe" &&
    $_SESSION["user"]["role"] !== "administrateur"
) {
    die("Accès interdit.");
}

if (!isset($_GET["id"])) {
    die("Commande introuvable.");
}

$commandeModel = new Commande($pdo);

$commande = $commandeModel->getById((int)$_GET["id"]);

if (!$commande) {
    die("Commande inexistante.");
}

$statuts = [
    "En attente",
    "Acceptée",
    "En préparation",
    "En cours de livraison",
    "Livrée",
    "En attente du retour de matériel",
    "Terminée"
];

$erreur = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nouveauStatut = $_POST["statut"];
    $commentaire = trim($_POST["commentaire"]);

    if (!in_array($nouveauStatut, $statuts)) {

        $erreur = "Statut invalide.";

    } else {

        // Mise à jour de la commande
        $commandeModel->updateStatut(
            $commande["id"],
            $nouveauStatut
        );

        // Historique
        $stmt = $pdo->prepare("
            INSERT INTO historique_statuts
            (commande_id, statut, commentaire)
            VALUES (?, ?, ?)
        ");

        $stmt->execute([
            $commande["id"],
            $nouveauStatut,
            $commentaire
        ]);

        header("Location: dashboard.php?status=ok");
        exit();
    }
}

include "../app/views/employee/change_status.php";