<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../app/config/database.php";
require_once "../app/helpers/session.php";

require_once "../app/models/Menu.php";
require_once "../app/models/Commande.php";

require_once "../app/services/CalculPrixService.php";

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET["menu"])) {
    die("Menu introuvable.");
}

$menuModel = new Menu($pdo);
$commandeModel = new Commande($pdo);

$menu = $menuModel->getById((int)$_GET["menu"]);

if (!$menu) {
    die("Menu inexistant.");
}

$user = $_SESSION["user"];

$erreur = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombrePersonnes = (int)$_POST["nombre_personnes"];

    if ($nombrePersonnes < $menu["nb_personnes_min"]) {

        $erreur = "Le minimum est de ".$menu["nb_personnes_min"]." personnes.";

    } else {

        $calcul = CalculPrixService::calculer(

            $menu["prix"],
            $menu["nb_personnes_min"],
            $nombrePersonnes,
            $_POST["ville"]

        );

        $commande = [

            "user_id"=>$user["id"],
            "menu_id"=>$menu["id"],

            "nom_client"=>$user["nom"],
            "prenom_client"=>$user["prenom"],
            "email_client"=>$user["email"],
            "telephone_client"=>$user["telephone"],

            "adresse_livraison"=>trim($_POST["adresse"]),
            "ville"=>trim($_POST["ville"]),

            "date_prestation"=>$_POST["date_prestation"],
            "heure_livraison"=>$_POST["heure_livraison"],

            "nombre_personnes"=>$nombrePersonnes,

            "prix_menu"=>$calcul["prix_menu"],
            "prix_livraison"=>$calcul["prix_livraison"],
            "remise"=>$calcul["remise"],
            "prix_total"=>$calcul["prix_total"]

        ];

        if($commandeModel->create($commande)){

            /*
             * Historique du statut
             */

            $stmt = $pdo->prepare("
                INSERT INTO historique_statuts
                (commande_id,statut)
                VALUES(?,?)
            ");

            $stmt->execute([
                $pdo->lastInsertId(),
                "En attente"
            ]);

            header("Location: ../user/dashboard.php?commande=ok");

            exit();

        }

        $erreur="Erreur lors de l'enregistrement.";

    }

}

include "../app/views/commande/create.php";